</div> <!-- container end -->

<footer class="text-center mt-5 py-4" style="background: #fff; border-top: 1px solid #eee;">
    <p class="mb-0 text-muted">© <?= date('Y') ?> Freelancer Market. Barcha huquqlar himoyalangan.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
