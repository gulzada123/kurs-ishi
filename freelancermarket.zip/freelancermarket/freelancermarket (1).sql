-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 07 2025 г., 00:32
-- Версия сервера: 8.0.19
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `freelancermarket`
--

-- --------------------------------------------------------

--
-- Структура таблицы `applications`
--

CREATE TABLE `applications` (
  `id` int NOT NULL,
  `job_id` int NOT NULL,
  `freelancer_id` int NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `applications`
--

INSERT INTO `applications` (`id`, `job_id`, `freelancer_id`, `message`, `created_at`) VALUES
(1, 21, 1, 'menga yoqadi', '2025-05-07 01:38:10'),
(2, 21, 1, 'kerek', '2025-05-07 02:08:16');

-- --------------------------------------------------------

--
-- Структура таблицы `jobs`
--

CREATE TABLE `jobs` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `employer_id` int NOT NULL,
  `budget` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `description`, `category`, `employer_id`, `budget`, `created_at`) VALUES
(21, 'Web sayt dizayni', 'Yangi startap uchun zamonaviy landing page kerak. Figma dizayni kerak.', 'web', 2, '500.00', '2025-05-06 19:38:15');

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `message` text NOT NULL,
  `sent_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `message`, `sent_at`) VALUES
(1, 2, 1, 'raqamim 93336666', '2025-05-07 02:06:36'),
(2, 2, 1, 'hop raqmat', '2025-05-07 02:07:13'),
(3, 8, 2, 'salem', '2025-05-07 02:15:28'),
(4, 8, 1, 'raqamim 93336666', '2025-05-07 02:15:38'),
(5, 8, 1, 'raqamim 93336666', '2025-05-07 02:15:39'),
(6, 2, 1, 'raqamim 93336666', '2025-05-07 02:28:07');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('freelancer','employer') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'otkir', 'otkir@gmail.com', '$2y$10$GayqBokYS3VVWdeZaC0AHO9sSbP7jfB3l/CXGER1T3u5IjYc7Yy.i', 'freelancer', '2025-05-06 18:31:59'),
(2, 'batir', 'batir@gmail.com', '$2y$10$M3watKM5aK6NSGTnnj85..VouE8qerDONb9WyVU2UXqvqiYuxeSd2', 'employer', '2025-05-06 19:30:27'),
(3, 'diyar', 'diyar@gmail.com', '$2y$10$LUq8.Gi5tvXzPDW4TLla8uMzniGy8P/xxTyf8.mYKU7nOi0fWCePG', 'freelancer', '2025-05-06 20:07:49'),
(4, 'shuka', 'shuka@gmail.com', '$2y$10$TYe5VRQFCQV1dQ/NZNQ3neMy.JBEh7EhwAYD.CJi17.aenfyTyc7a', 'freelancer', '2025-05-06 20:09:22'),
(5, 'diyar', 'otkirbek@gmail.com', '$2y$10$wR8emOLcQ6B0BN8kqnZlUeaVorw0/gJi7ltd0HlSGQg4wf8dEFtTC', 'freelancer', '2025-05-06 20:10:56'),
(6, 'shuka', 'otkirbek88@gmail.com', '$2y$10$Y5GL1F49xuXJ/d.o8G8E/el67vtF8LgSkL.Lhc/SKfeRuHtR/GktG', 'freelancer', '2025-05-06 20:13:15'),
(7, 'tfyfy', 'bati77r@gmail.com', '$2y$10$rOQ4do/qrXM7.JvAr2t8pORpHYEt3mvK5Y3gSCecZsa3YsHLh2S1G', 'employer', '2025-05-06 20:18:19'),
(8, 'asad', 'asad@gmail.com', '$2y$10$qAFO0W8MKoxiTdKB8bD36.Mi7GybqhoyJGYy/s/FQhpUFhSn9Oogm', 'freelancer', '2025-05-06 21:14:53');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `freelancer_id` (`freelancer_id`);

--
-- Индексы таблицы `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employer_id` (`employer_id`);

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `applications`
--
ALTER TABLE `applications`
  ADD CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  ADD CONSTRAINT `applications_ibfk_2` FOREIGN KEY (`freelancer_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`employer_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
